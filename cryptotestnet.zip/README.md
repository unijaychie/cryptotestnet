# CryptoTestnet

A simple testnet token dApp with a smart contract in Solidity and a minimal HTML/JS frontend.

## How to Use
1. Deploy `contracts/CryptoTestnet.sol` using Remix on a testnet (e.g., Sepolia).
2. Replace `YOUR_DEPLOYED_CONTRACT_ADDRESS` in `frontend/script.js` with your deployed address.
3. Open `frontend/index.html` in your browser.
4. Connect MetaMask, check balance, and send tokens.
